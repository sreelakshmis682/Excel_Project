--              Task 6: Shipment Tracking Analytics

-- 1)For each shipment, display the latest status (Delivered, In Transit, or Returned) along with the latest Delivery_Date.
SELECT s.Shipment_ID,
       s.Delivery_Status,
       s.Delivery_Date
FROM fedex_Shipments s
JOIN (
    SELECT Shipment_ID, MAX(Delivery_Date) AS Latest_Delivery_Date
    FROM  fedex_Shipments
    GROUP BY Shipment_ID
) t
ON s.Shipment_ID = t.Shipment_ID
AND s.Delivery_Date = t.Latest_Delivery_Date;

-- 2)Identify routes where the majority of shipments are still “In Transit” or “Returned”. 
WITH route_counts AS (
    SELECT
        Route_ID,
        COUNT(*) AS Total_Shipments,
        SUM(CASE
                WHEN Delivery_Status IN ('In Transit', 'Returned') THEN 1
                ELSE 0
            END) AS Problem_Shipments
    FROM fedex_shipments
    GROUP BY Route_ID
)
SELECT
    Route_ID,
    Total_Shipments,
    Problem_Shipments,
    CASE
        WHEN Problem_Shipments > Total_Shipments / 2 THEN 'YES'
        ELSE 'NO'
    END AS Majority_Problem
FROM route_counts;


-- 3)Find the most frequent delay reasons (if available in delay-related columns or flags). 
SELECT Delay_Reason, COUNT(*) AS Frequency
FROM fedex_Shipments
WHERE Delay_Reason IS NOT NULL
GROUP BY Delay_Reason
ORDER BY Frequency DESC;

-- 4)Identify orders with exceptionally high delay (>120 hours) to investigate potential bottlenecks.
SELECT
    Order_ID,
    Delay_Hours
FROM fedex_shipments
WHERE Delay_Hours > 120
ORDER BY Delay_Hours DESC;

