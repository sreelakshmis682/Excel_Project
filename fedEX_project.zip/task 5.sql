--   Task:5 Delivery Agent Performance 
-- 1) Rank delivery agent (per route) by on-time delivery percentage
SELECT
    s.Route_ID,
    a.Agent_ID,
    ROUND(
        100.0 * SUM(
            CASE
                WHEN TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date)
                     <= r.Avg_Transit_Time_Hours
                THEN 1 ELSE 0
            END
        ) / COUNT(*),
        2
    ) AS On_Time_Percentage,
    RANK() OVER (
        PARTITION BY s.Route_ID
        ORDER BY
            100.0 * SUM(
                CASE
                    WHEN TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date)
                         <= r.Avg_Transit_Time_Hours
                    THEN 1 ELSE 0
                END
            ) / COUNT(*) DESC
    ) AS Agent_Rank
FROM fedex_shipments s
JOIN fedex_routes r
    ON s.Route_ID = r.Route_ID
JOIN fedex_delivery_agents a
    ON s.Agent_ID = a.Agent_ID
GROUP BY
    s.Route_ID,
    a.Agent_ID
ORDER BY
    s.Route_ID,
    Agent_Rank;

-- 2) find agent whose on-time % is below 85%

SELECT 
    a.Agent_ID,
    a.Agent_Name,
    COUNT(s.Shipment_ID) AS Total_Shipments,
    SUM(CASE WHEN s.Delay_Hours <= 0 THEN 1 ELSE 0 END) AS On_Time_Shipments,
    ROUND((SUM(CASE WHEN s.Delay_Hours <= 0 THEN 1 ELSE 0 END) / COUNT(s.Shipment_ID)) * 100, 2) AS On_Time_Percentage
FROM fedex_delivery_agents a
JOIN fedex_shipments s ON a.Agent_ID = s.Agent_ID
GROUP BY a.Agent_ID, a.Agent_Name
HAVING On_Time_Percentage < 85;

-- 3)Compare the average rating and experience (in years) of the top 5 vs bottom 5 agents using subqueries. 
-- Top 5 Agents

  (SELECT 'Top 5' AS Group_Label, Agent_ID, Agent_Name, Experience_Years, Avg_Rating
    FROM fedex_delivery_agents
    ORDER BY Experience_Years DESC
    LIMIT 5)
UNION ALL
(SELECT 'Bottom 5' AS Group_Label, Agent_ID, Agent_Name, Experience_Years, Avg_Rating
    FROM fedex_delivery_agents
    ORDER BY Experience_Years ASC
    LIMIT 5);

--  4)Suggest training or workload balancing strategies for low-performing agents based on insights. 

-- Training Recommendations –  Provide route-specific training to agents with on-time delivery below 85%, Assign experienced, top-performing agents as mentors, Conduct time management and delivery planning training.
-- Workload Balancing Strategies - Assign shorter or less complex routes to low performers, Assign complex or high-volume routes to more experienced agents.
-- Route & Process Optimization - Review routes with frequent delays and make adjustments, 
-- Technology & Support - Ensure agents are trained on navigation and tracking tools, Use real-time alerts to help agents avoid traffic delays.
-- Feedback - Share regular performance feedback with agents, Identify recurring delay reasons and address them quickly.
