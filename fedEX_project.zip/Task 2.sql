--                       Task:2 Delivery Delay Analysis

-- 1)Calculate delivery delay(in hours) for each shipment using Delivery_Date-Pickup_Date
 SELECT
    Shipment_ID,
    Pickup_Date,
    Delivery_Date,
    TIMESTAMPDIFF(HOUR, Pickup_Date, Delivery_Date) AS Delivery_Delay_Hours
FROM fedex_shipments;

-- 2)find the Top 10 delayed routes based on average delay hours
SELECT 
    Route_ID,
    AVG(Delay_Hours) AS Avg_Delay_Hours
FROM 
   fedex_shipments
GROUP BY 
    Route_ID
ORDER BY 
    Avg_Delay_Hours DESC
LIMIT 10;

-- 3)Use SQL window functions to rank shipments by delay within each Warehouse_ID. 
SELECT
    o.Delivery_Type,
    ROUND(AVG(s.Delay_Hours), 2) AS Avg_Delay_Hours
FROM fedex_orders o
JOIN fedex_shipments s
    ON o.Order_ID = s.Order_ID
GROUP BY o.Delivery_Type;


-- 4)Identify the average delay per Delivery_Type (Express / Standard) to compare service-level effiency
SELECT 
    Delivery_Status,
    AVG(Delay_Hours) AS Avg_Delay_Hours
FROM fedex_shipments
WHERE Delay_Hours > 0
GROUP BY Delivery_Status;
