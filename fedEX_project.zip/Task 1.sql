--                       Task:1 Date Cleaning & Preparation

--  1)Identify and delete duplicate Order_ID or Shipment_ID records.
create database FedEx;
use fedex;
show table status;
select * from fedex_delivery_agents;
select * from fedex_orders;
select * from fedex_routes;
select * from fedex_shipments;
select * from fedex_warehouses;

DELETE s1
FROM fedex_Shipments s1
JOIN fedex_Shipments s2
ON s1.Shipment_ID = s2.Shipment_ID
AND s1.Order_ID > s2.Order_ID;
select * from fedex_shipments;
select * from fedex_orders;

--   2)Replace null or missing Delay_Hours values in the Shipments Table with the average delay for that Route_ID.
UPDATE fedex_shipments f
SET Delay_Hours = (
    SELECT avg_delay
    FROM (
        SELECT Route_ID, AVG(Delay_Hours) AS avg_delay
        FROM fedex_shipments
        WHERE Delay_Hours IS NOT NULL
        GROUP BY Route_ID
    ) t
    WHERE t.Route_ID = f.Route_ID
)
WHERE f.Delay_Hours IS NULL;
select * from fedex_shipmentS;

-- 3)Convert all date columns (Order_Date, Pickup_Date, Delivery_Date) into YYYY-MM-DD HH:MM:SS format using SQL date functions.
SELECT
  DATE_FORMAT(Delivery_Date, '%Y-%m-%d %H:%i:%s') AS Delivery_Date
FROM fedex_shipments;

-- 4)Ensure that no Delivery_Date occurs before Pickup_Date (flag such records).
SELECT *,
       CASE 
           WHEN Delivery_Date < Pickup_Date THEN 'Flagged: Invalid Date'
           ELSE 'Valid'
       END AS Record_Status
FROM fedex_shipments;

-- 5)Validate referential integrity between Orders, Routes, Warehouses, and Shipment
SELECT
    s.Shipment_ID,
    o.Order_ID,
    r.Route_ID,
    w.Warehouse_ID
FROM fedex_shipments s
JOIN fedex_orders o
    ON s.Order_ID = o.Order_ID
JOIN fedex_routes r
    ON o.Route_ID = r.Route_ID
JOIN fedex_warehouses w
    ON s.Warehouse_ID = w.Warehouse_ID;
    