--                       Task:4 Warehouse performance

--    1)find the top 3 warehouses with the highest average delay in shipment dispatched
SELECT
    w.Warehouse_ID,
    AVG(
        TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date)
        - r.Avg_Transit_Time_Hours
    ) AS Avg_Dispatch_Delay_Hours
FROM fedex_shipments s
JOIN fedex_routes r
    ON s.Route_ID = r.Route_ID
JOIN fedex_warehouses w
    ON s.Warehouse_ID = w.Warehouse_ID
GROUP BY
    w.Warehouse_ID
ORDER BY Avg_Dispatch_Delay_Hours DESC
LIMIT 3;

-- 2) Calculate total shipments vs delayed shipments for each warehouses
SELECT
    w.Warehouse_ID,
    COUNT(*) AS Total_Shipments,
    SUM(CASE 
            WHEN s.Delay_Hours > 24 THEN 1 
            ELSE 0 
        END) AS Delayed_Shipments,
    (SUM(CASE 
            WHEN s.Delay_Hours > 24 THEN 1 
            ELSE 0 
        END) / COUNT(*)) * 100 AS Percent_Delayed
FROM fedex_warehouses w
JOIN fedex_shipments s
    ON w.Warehouse_ID = s.Warehouse_ID
GROUP BY w.Warehouse_ID
ORDER BY Percent_Delayed DESC;
    -- 3)use CTES to identify warehouses where average delay exceeds the global average delay
 WITH warehouse_avg_delay AS (
    SELECT
        Warehouse_ID,
        ROUND(AVG(Delay_Hours), 2) AS Avg_Warehouse_Delay
    FROM fedex_shipments
    GROUP BY Warehouse_ID
),
global_avg_delay AS (
    SELECT
        ROUND(AVG(Delay_Hours), 2) AS Global_Avg_Delay
    FROM fedex_shipments
)
SELECT
    w.Warehouse_ID,
    w.Avg_Warehouse_Delay,
    g.Global_Avg_Delay
FROM warehouse_avg_delay w
CROSS JOIN global_avg_delay g
WHERE w.Avg_Warehouse_Delay > g.Global_Avg_Delay
ORDER BY w.Avg_Warehouse_Delay DESC;

    
--   4) Rank all warehouses based on on-time delivery percentage
WITH shipment_data AS (
    SELECT
        Warehouse_ID,
        Delay_Hours,
        AVG(Delay_Hours) OVER (PARTITION BY Warehouse_ID) AS Avg_Warehouse_Delay
    FROM fedex_shipments
),
warehouse_summary AS (
    SELECT
        Warehouse_ID,
        COUNT(*) AS Total_Shipments,
        SUM(CASE WHEN Delay_Hours <= Avg_Warehouse_Delay THEN 1 ELSE 0 END) AS On_Time_Shipments
    FROM shipment_data
    GROUP BY Warehouse_ID
)
SELECT
    Warehouse_ID,
    Total_Shipments,
    On_Time_Shipments,
    ROUND((On_Time_Shipments * 100.0) / Total_Shipments, 2) AS On_Time_Percentage,
    RANK() OVER (
        ORDER BY (On_Time_Shipments * 1.0) / Total_Shipments DESC
    ) AS Warehouse_Rank
FROM warehouse_summary
ORDER BY Warehouse_Rank;
