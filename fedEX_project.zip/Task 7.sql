		--                             Tak 7: Advanced KPI Reporting
--   Create SQL queries to calculate and summarize the following KPIs: 
--   1)Average Delivery Delay per Source_Country. 

SELECT 
    r.Source_City, 
    ROUND( AVG(s.Delay_Hours), 2 ) AS AVERAGE_DELAY
FROM 
    fedex_routes r
JOIN 
    fedex_shipments s ON r.Route_ID = s.Route_ID
GROUP BY Source_City;

--- 2)On-Time Delivery % = (Total On-Time Deliveries / Total Deliveries) * 100.
SELECT
    s.Route_ID,
    COUNT(*) AS Total_Deliveries,
    SUM(
        CASE
            WHEN s.Delay_Hours <= r.Avg_Transit_Time_Hours THEN 1
            ELSE 0
        END
    ) AS On_Time_Deliveries,
    ROUND(
        (SUM(CASE WHEN s.Delay_Hours <= r.Avg_Transit_Time_Hours THEN 1 ELSE 0 END) * 100.0) / COUNT(*),
        2
    ) AS On_Time_Percentage
FROM fedex_shipments s
JOIN fedex_routes r
    ON s.Route_ID = r.Route_ID
GROUP BY s.Route_ID
ORDER BY On_Time_Percentage DESC;

-- 3)Average Delay (in hours) per Route_ID.
SELECT 
    Route_ID,
    AVG(Delay_Hours) AS Avg_Delay_Hours
FROM 
   fedex_Shipments
GROUP BY 
    Route_ID;
    
-- 4)Warehouse Utilization % = (Shipments_Handled / Capacity_per_day) * 100.
SELECT 
    w.Warehouse_ID,
    (COUNT(s.Shipment_ID) * 100.0 / w.Capacity_per_day) AS Warehouse_Utilization_Percentage
FROM fedex_warehouses w
LEFT JOIN fedex_shipments s
    ON w.Warehouse_ID = s.Warehouse_ID
GROUP BY w.Warehouse_ID, w.Capacity_per_day;