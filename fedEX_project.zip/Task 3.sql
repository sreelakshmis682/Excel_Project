--           Task 3: Route Optimization Insights

--     1) Average transit time(in hours) across all shipments.

SELECT AVG(TIMESTAMPDIFF(HOUR, Pickup_Date, Delivery_Date)) AS Avg_Transit_Hours
FROM fedex_shipments
WHERE Pickup_Date IS NOT NULL AND Delivery_Date IS NOT NULL;

--  2) Average delay(in hours)per route.
SELECT 
    Route_ID,
    AVG(TIMESTAMPDIFF(HOUR, Pickup_Date, Delivery_Date)) AS Avg_Delay_Hours
FROM fedex_shipments
WHERE Pickup_Date IS NOT NULL 
  AND Delivery_Date IS NOT NULL
GROUP BY Route_ID;

--    3) Distance-to-time efficiency ratio = Distance_KM / Avg_Transit_Time_Hours
SELECT 
    Distance_KM, 
    Avg_Transit_Time_Hours, 
    ROUND((Distance_KM / Avg_Transit_Time_Hours), 2) AS Distance_to_Time_Efficiency
FROM 
    fedex_routes 
ORDER BY 
    Distance_to_Time_Efficiency DESC;

-- 4)Identify 3 routes with the worst efficiency ratio(lowest distance-to-time)
SELECT 
    Distance_KM, 
    Avg_Transit_Time_Hours, 
    ROUND((Distance_KM / Avg_Transit_Time_Hours), 2) AS Distance_to_Time_Efficiency
FROM 
    fedex_routes 
ORDER BY 
    Distance_to_Time_Efficiency ASC
LIMIT 3;
    

-- 5)find routes with>20% 0f shipments delayed beyond expected transit time
SELECT
    s.Route_ID
FROM fedex_shipments s
JOIN fedex_routes r
    ON s.Route_ID = r.Route_ID
GROUP BY s.Route_ID
HAVING
    SUM(
        CASE
            WHEN TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date)
                 > r.Avg_Transit_Time_Hours
            THEN 1 ELSE 0
        END
    ) / COUNT(*) > 0.20;
    
    -- 6) Recommend potential routes or hub pairs for optimization.
    
-- 1) Identify delays early - use weather and historical data to spot high-risk flights in advance and take action before delays occur.
-- 2) Share information in real time -  Improve communication between hubs and stations so teams can adjust operations immediately.
-- 3) Prioritize critical shipments first - Load time-sensitive and high-priority shipments earlier to reduce the impact of delays on service commitments.

 
